# RACI (prototype)

| Domaine                         | R (fait) | A (approuve) | C (consulté) | I (informé) |
|--------------------------------|----------|--------------|--------------|-------------|
| Design IP plan/VLAN            | Bac+3    | Bac+5        | Bac+2        | Encadrants  |
| Golden config switch           | Bac+3    | Bac+5        | Bac+2        | Encadrants  |
| Proxmox setup                  | Bac+3    | Bac+5        | Bac+2        | Encadrants  |
| Création VMs (DHCP/DNS/Apache) | Bac+2    | Bac+3        | Bac+5        | Encadrants  |
| Ansible (rôles/CI)             | Bac+3    | Bac+5        | Bac+2        | Encadrants  |
| Supervision & sauvegardes      | Bac+3    | Bac+5        | Bac+2        | Encadrants  |
| Documentation/runbooks         | Bac+2    | Bac+5        | Bac+3        | Encadrants  |

