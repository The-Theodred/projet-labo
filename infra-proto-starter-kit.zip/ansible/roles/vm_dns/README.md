# Rôle `vm_dns`

> Décrire variables, handlers, tâches et tests.
