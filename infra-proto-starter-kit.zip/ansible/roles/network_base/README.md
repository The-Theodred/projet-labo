# Rôle `network_base`

> Décrire variables, handlers, tâches et tests.
