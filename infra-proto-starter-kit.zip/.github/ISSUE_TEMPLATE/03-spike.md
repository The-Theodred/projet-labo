---
name: Spike (exploration)
about: Recherche limitée dans le temps avec livrables concrets
labels: ["Spike"]
---

## Question
...

## Timebox
... (ex. 0,5 j)

## Livrables
- Option(s) recommandée(s)
- Critères de choix
- POC minimal
