---
name: Tâche B2 (exécutable)
about: Tâche pour technicien avec procédure claire
labels: ["B2"]
---

## Objectif
Décrire le résultat attendu.

## Procédure pas-à-pas
1. ...
2. ...

## Critères d'acceptation
- [ ] Vérif 1
- [ ] Vérif 2

## Liens
Runbook/Schéma/PR :
