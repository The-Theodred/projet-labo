# Agendas types

## Daily (10 min)
- Hier / Aujourd'hui / Blocages (tour rapide)
- Risques nouveaux ?
- Actions d'escalade (si besoin)

## Revue hebdo (30 min)
- Démo des user stories Done
- Avancement vs Sprint Goal
- Décisions/Arbitrages (max 10') – actés par écrit
- Prochaines priorités

## Rétro (20 min)
- 👍 À garder | 🔧 À améliorer | 🛑 À arrêter
- Action items avec propriétaires et échéance
