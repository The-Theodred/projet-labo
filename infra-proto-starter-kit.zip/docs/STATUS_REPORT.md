# Modèle de reporting hebdo

**Semaine du :** YYYY-MM-DD  
**Sprint :** Sxx

## Faits marquants
- ...

## Avancement
- Stories Done / en cours / à risque

## Risques & décisions
- R1: ... (probabilité/impact, parade)
- Décisions prises : ... (lien PR/Issue)

## Prochaines étapes
- ...
