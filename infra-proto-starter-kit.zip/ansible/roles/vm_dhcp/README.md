# Rôle `vm_dhcp`

> Décrire variables, handlers, tâches et tests.
