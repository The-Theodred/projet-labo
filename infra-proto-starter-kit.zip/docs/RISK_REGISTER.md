# Registre des risques

| ID | Risque | Prob. | Impact | Stratégie | Propriétaire | Échéance | État |
|----|--------|-------|--------|-----------|--------------|----------|------|
| R1 | Matériel hétérogène/firmwares | M | M | Standardiser + inventaire | Bac+3 | Semaine 1 | Ouvert |
| R2 | Droits d'accès manquants      | M | H | Demandes anticipées        | Bac+5 | Semaine 1 | Ouvert |
| R3 | Debt de doc                   | H | M | DoD stricte + revue        | Bac+5 | Continu   | Ouvert |
