# Rôle `proxmox_vms`

> Décrire variables, handlers, tâches et tests.
