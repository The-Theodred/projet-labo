# Rôle `proxmox_base`

> Décrire variables, handlers, tâches et tests.
