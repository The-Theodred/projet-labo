---
name: Tâche B3 (conception/automatisation)
about: Conception, standardisation, Ansible, sécurité
labels: ["B3"]
---

## Contexte
...

## Livrables
- Doc/design
- Code (rôle/playbook)
- Tests

## DoR
- [ ] Périmètre clair
- [ ] Dépendances identifiées

## DoD
- [ ] Doc à jour
- [ ] CI verte
- [ ] Tests passants
