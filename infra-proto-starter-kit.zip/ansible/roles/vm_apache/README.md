# Rôle `vm_apache`

> Décrire variables, handlers, tâches et tests.
