## Objet
- ...

## Checklist DoD
- [ ] Doc à jour (README/runbook)
- [ ] Ansible/yaml lint OK
- [ ] Tests passants (`--check` si applicable)
- [ ] Supervision/logs ok (si pertinent)
- [ ] Reviewer ajouté

## Validation
- Captures/logs de test :
